module com.example.ticctactoe {
	requires javafx.controls;
	requires javafx.fxml;


	opens com.example.ticctactoe to javafx.fxml;
	exports com.example.ticctactoe;
}